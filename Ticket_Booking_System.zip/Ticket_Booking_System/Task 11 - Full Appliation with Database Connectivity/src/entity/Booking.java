package entity;

import java.util.List;

public class Booking {
    private String bookingId;
    private Event event;
    private List<Customer> customers;
    private int totalTickets;
    private double totalCost;

    public Booking(String bookingId, Event event, List<Customer> customers, int totalTickets) {
        this.bookingId = bookingId;
        this.event = event;
        this.customers = customers;
        this.totalTickets = totalTickets;
        this.totalCost = event.getTicketPrice() * totalTickets;
    }

    public String getBookingId() { return bookingId; }
    public Event getEvent() { return event; }
    public List<Customer> getCustomers() { return customers; }
    public int getTotalTickets() { return totalTickets; }
    public double getTotalCost() { return totalCost; }

    @Override
    public String toString() {
        return "Booking ID: " + bookingId + ", Event: " + event.getEventName() + ", Total Cost: " + totalCost;
    }
}