package entity;

import java.time.LocalDate;
import java.time.LocalTime;

public class Movie extends Event {

    public Movie(String eventName, String date, String time, Venue venue, int totalSeats, double ticketPrice) {
        super(eventName, date, time, venue, totalSeats, ticketPrice, "Movie");
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Movie: " + eventName);
        System.out.println("Date: " + eventDate);
        System.out.println("Time: " + eventTime);
        System.out.println("Venue: " + venue);
        System.out.println("Total Seats: " + totalSeats);
        System.out.println("Available Seats: " + availableSeats);
        System.out.println("Ticket Price: " + ticketPrice);
    }
}