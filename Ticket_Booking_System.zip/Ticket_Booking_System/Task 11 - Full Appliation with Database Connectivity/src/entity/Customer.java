package entity;

public class Customer {
    private String customerName;
    private String contactNumber;
    private String email;

    public Customer(String customerName, String contactNumber, String email) {
        this.customerName = customerName;
        this.contactNumber = contactNumber;
        this.email = email;
    }

    public String getCustomerName() { return customerName; }
    public String getContactNumber() { return contactNumber; }
    public String getEmail() { return email; }

    @Override
    public String toString() {
        return customerName + " (" + contactNumber + ")";
    }
}
