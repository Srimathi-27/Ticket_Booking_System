package entity;

import java.time.LocalDate;
import java.time.LocalTime;

public abstract class Event {
    protected String eventName;
    protected LocalDate eventDate;
    protected LocalTime eventTime;
    protected Venue venue;
    protected int totalSeats;
    protected int availableSeats;
    protected double ticketPrice;
    protected String eventType;

    public Event() {}

    public Event(String eventName, String date, String time, Venue venue, int totalSeats, double ticketPrice, String eventType) {
        this.eventName = eventName;
        this.eventDate = LocalDate.parse(date);
        this.eventTime = LocalTime.parse(time);
        this.venue = venue;
        this.totalSeats = totalSeats;
        this.availableSeats = totalSeats;
        this.ticketPrice = ticketPrice;
        this.eventType = eventType;
    }

    public String getEventName() { return eventName; }
    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int seats) { this.availableSeats = seats; }
    public double getTicketPrice() { return ticketPrice; }
    public String getEventType() { return eventType; }

    public abstract void displayEventDetails();
}
