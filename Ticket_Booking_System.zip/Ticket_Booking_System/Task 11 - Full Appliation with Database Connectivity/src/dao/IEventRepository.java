package dao;

import entity.Event;
import exception.EventNotFoundException;
import java.util.List;

public interface IEventRepository {
    Event getEventByName(String eventName) throws EventNotFoundException;
    List<Event> getAllEvents();
    void addEvent(Event event);
}
