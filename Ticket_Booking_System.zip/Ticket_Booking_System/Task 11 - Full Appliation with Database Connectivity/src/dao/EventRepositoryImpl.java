package dao;

import entity.Event;
import exception.EventNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class EventRepositoryImpl implements IEventRepository {
    private List<Event> eventList = new ArrayList<>();

    @Override
    public Event getEventByName(String eventName) throws EventNotFoundException {
        for (Event event : eventList) {
            if (event.getEventName().equals(eventName)) {
                return event;
            }
        }
        throw new EventNotFoundException("Event not found: " + eventName);
    }

    @Override
    public List<Event> getAllEvents() {
        return eventList;
    }

    @Override
    public void addEvent(Event event) {
        eventList.add(event);
    }
}
