package dao;

import entity.Booking;
import entity.Event;
import exception.InvalidBookingIDException;
import entity.Customer;
import java.util.List;

public interface IBookingSystemRepository {
    Booking createBooking(String bookingId, Event event, List<Customer> customers, int totalTickets);
    Booking getBookingById(String bookingId) throws InvalidBookingIDException;
    List<Booking> getBookingsByEvent(Event event);
    boolean cancelBooking(String bookingId);
}
