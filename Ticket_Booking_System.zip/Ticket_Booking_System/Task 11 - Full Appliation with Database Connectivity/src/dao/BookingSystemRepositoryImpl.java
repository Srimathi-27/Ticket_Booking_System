package dao;

import entity.Booking;
import entity.Event;
import entity.Customer;
import exception.InvalidBookingIDException;

import java.util.ArrayList;
import java.util.List;

public class BookingSystemRepositoryImpl implements IBookingSystemRepository {

    private List<Booking> bookingList = new ArrayList<>();

    @Override
    public Booking createBooking(String bookingId, Event event, List<Customer> customers, int totalTickets) {
        Booking booking = new Booking(bookingId, event, customers, totalTickets);
        bookingList.add(booking);
        return booking;
    }

    @Override
    public Booking getBookingById(String bookingId) throws InvalidBookingIDException {
        for (Booking booking : bookingList) {
            if (booking.getBookingId().equals(bookingId)) {
                return booking;
            }
        }
        throw new InvalidBookingIDException("Booking ID not found: " + bookingId);
    }

    @Override
    public List<Booking> getBookingsByEvent(Event event) {
        List<Booking> bookingsForEvent = new ArrayList<>();
        for (Booking booking : bookingList) {
            if (booking.getEvent().equals(event)) {
                bookingsForEvent.add(booking);
            }
        }
        return bookingsForEvent;
    }

    @Override
    public boolean cancelBooking(String bookingId) {
        try {
            Booking booking = getBookingById(bookingId);
            return bookingList.remove(booking);
        } catch (InvalidBookingIDException e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }
}