package service;

import entity.Event;
import java.util.List;

public interface IEventServiceProvider {
    Event getEventByName(String eventName);
    List<Event> getAllEvents();
    void addEvent(Event event);
}
