package service;

import dao.BookingSystemRepositoryImpl;
import dao.IBookingSystemRepository;
import entity.Booking;
import entity.Customer;
import entity.Event;
import exception.InvalidBookingIDException;

import java.util.List;

public class BookingSystemServiceProviderImpl implements IBookingSystemServiceProvider {

    private final IBookingSystemRepository bookingRepo;

    public BookingSystemServiceProviderImpl() {
        this.bookingRepo = new BookingSystemRepositoryImpl();
    }

    @Override
    public Booking createBooking(String bookingId, Event event, List<Customer> customers, int totalTickets) {
        return bookingRepo.createBooking(bookingId, event, customers, totalTickets);
    }

    @Override
    public Booking getBookingById(String bookingId) throws InvalidBookingIDException {
        return bookingRepo.getBookingById(bookingId);
    }

    @Override
    public boolean cancelBooking(String bookingId) {
        return bookingRepo.cancelBooking(bookingId);
    }
}
