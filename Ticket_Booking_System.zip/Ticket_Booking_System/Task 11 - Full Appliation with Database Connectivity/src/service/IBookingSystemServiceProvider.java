package service;

import entity.Booking;
import entity.Event;
import exception.InvalidBookingIDException;
import entity.Customer;
import java.util.List;

public interface IBookingSystemServiceProvider {
    Booking createBooking(String bookingId, Event event, List<Customer> customers, int totalTickets);
    Booking getBookingById(String bookingId) throws InvalidBookingIDException;
    boolean cancelBooking(String bookingId);
}