package service;

import entity.Booking;
import entity.Event;
import entity.Customer;

import java.util.List;

public interface IBookingSystemRepository {

    Event createEvent(String eventName, String date, String time, int totalSeats, double ticketPrice, String eventType, String venue);

    List<Event> getEventDetails();

    int getAvailableNoOfTickets();

    double calculateBookingCost(int numTickets, Event event);

    Booking bookTickets(String eventName, int numTickets, List<Customer> customers);

    boolean cancelBooking(String bookingId);

    Booking getBookingDetails(String bookingId);
}