package service;

import dao.IEventRepository;
import dao.EventRepositoryImpl;
import entity.Event;
import exception.EventNotFoundException;
import java.util.List;

public class EventServiceProviderImpl implements IEventServiceProvider {
    private IEventRepository eventRepository = new EventRepositoryImpl();

    @Override
    public Event getEventByName(String eventName) {
        try {
            return eventRepository.getEventByName(eventName);
        } catch (EventNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Event> getAllEvents() {
        return eventRepository.getAllEvents();
    }

    @Override
    public void addEvent(Event event) {
        eventRepository.addEvent(event);
    }
}