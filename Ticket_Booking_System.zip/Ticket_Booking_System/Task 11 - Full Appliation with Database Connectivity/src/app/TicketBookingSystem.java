package app;

import entity.*;
import service.BookingSystemServiceProviderImpl;
import service.EventServiceProviderImpl;
import service.IBookingSystemServiceProvider;
import service.IEventServiceProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TicketBookingSystem {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        IEventServiceProvider eventService = new EventServiceProviderImpl();
        IBookingSystemServiceProvider bookingService = new BookingSystemServiceProviderImpl();

        while (true) {
            System.out.println("\n==== Ticket Booking System ====");
            System.out.println("1. Create Event");
            System.out.println("2. Display All Events");
            System.out.println("3. Book Tickets");
            System.out.println("4. Cancel Booking");
            System.out.println("5. Show Booking By ID");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    System.out.print("Enter event type (Movie/Concert/Sport): ");
                    String type = scanner.nextLine();
                    System.out.print("Enter event name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter event date (YYYY-MM-DD): ");
                    String date = scanner.nextLine();
                    System.out.print("Enter event time (HH:MM): ");
                    String time = scanner.nextLine();
                    System.out.print("Enter venue location: ");
                    String location = scanner.nextLine();
                    System.out.print("Enter venue city: ");
                    String city = scanner.nextLine();
                    System.out.print("Enter total seats: ");
                    int seats = Integer.parseInt(scanner.nextLine());
                    System.out.print("Enter ticket price: ");
                    double price = Double.parseDouble(scanner.nextLine());

                    Venue venue = new Venue(location, city);
                    Event event = null;

                    switch (type.toLowerCase()) {
                        case "movie":
                            event = new Movie(name, date, time, venue, seats, price);
                            break;
                        case "concert":
                            event = new Concert(name, date, time, venue, seats, price);
                            break;
                        case "sport":
                            event = new Sport(name, date, time, venue, seats, price);
                            break;
                        default:
                            System.out.println("Invalid event type.");
                    }

                    if (event != null) {
                        eventService.addEvent(event);
                        System.out.println("Event created successfully!");
                    }
                    break;

                case 2:
                    System.out.println("All Events:");
                    for (Event e : eventService.getAllEvents()) {
                        e.displayEventDetails();
                        System.out.println("---------------");
                    }
                    break;

                case 3:
                    System.out.print("Enter booking ID: ");
                    String bookingId = scanner.nextLine();
                    System.out.print("Enter event name to book: ");
                    String eventName = scanner.nextLine();
                    Event bookingEvent = eventService.getEventByName(eventName);

                    if (bookingEvent == null) {
                        System.out.println("Event not found.");
                        break;
                    }

                    System.out.print("Enter number of tickets: ");
                    int totalTickets = Integer.parseInt(scanner.nextLine());

                    if (totalTickets > bookingEvent.getAvailableSeats()) {
                        System.out.println("Not enough seats available.");
                        break;
                    }

                    List<Customer> customers = new ArrayList<>();
                    for (int i = 1; i <= totalTickets; i++) {
                        System.out.println("Enter details for customer " + i + ":");
                        System.out.print("Name: ");
                        String cname = scanner.nextLine();
                        System.out.print("Contact: ");
                        String contact = scanner.nextLine();
                        System.out.print("Email: ");
                        String email = scanner.nextLine();
                        customers.add(new Customer(cname, contact, email));
                    }

                    bookingEvent.setAvailableSeats(bookingEvent.getAvailableSeats() - totalTickets);
                    Booking booking = bookingService.createBooking(bookingId, bookingEvent, customers, totalTickets);
                    System.out.println("Booking successful: " + booking);
                    break;

                case 4:
                    System.out.print("Enter booking ID to cancel: ");
                    String cancelId = scanner.nextLine();
                    boolean success = bookingService.cancelBooking(cancelId);
                    if (success) {
                        System.out.println("Booking cancelled.");
                    } else {
                        System.out.println("Booking not found.");
                    }
                    break;

                case 5:
                    System.out.print("Enter booking ID: ");
                    String searchId = scanner.nextLine();
                    try {
                        Booking foundBooking = bookingService.getBookingById(searchId);
                        System.out.println("Booking Found: " + foundBooking);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 6:
                    System.out.println("Exiting... Thank you!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
