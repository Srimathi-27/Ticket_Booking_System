package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/TicketBookingSystem"; 
    private static final String USER = "root";  
    private static final String PASSWORD = "Rsrimathi@2741";  

    public static Connection getDBConn() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  
            return DriverManager.getConnection(URL, USER, PASSWORD);  
        } catch (ClassNotFoundException | SQLException e) {
            throw new SQLException("Database connection error: " + e.getMessage());
        }
    }
}