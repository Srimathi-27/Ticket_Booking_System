package Main;
import Entity.*;
import java.util.Scanner;

public class TicketBookingSystem {

    public Event create_event(String event_name, String date, String time, int total_seats, double ticket_price, String event_type, String venue_name) {
        Scanner sc = new Scanner(System.in);

        if (event_type.equalsIgnoreCase("Movie")) {
            System.out.print("Enter genre: ");
            String genre = sc.nextLine();
            System.out.print("Enter ActorName: ");
            String actorName = sc.nextLine();
            System.out.print("Enter ActresName: ");
            String actressName = sc.nextLine();
            return new Movie(event_name, date, time, venue_name, total_seats, ticket_price, event_type, genre, actorName);

        } else if (event_type.equalsIgnoreCase("Concert")) {
            System.out.print("Enter artist name: ");
            String artist = sc.nextLine();
            System.out.print("Enter type ");
            String type = sc.nextLine();
            return new Concert(event_name, date, time, venue_name, total_seats, ticket_price, event_type, artist);

        } else if (event_type.equalsIgnoreCase("Sports")) {
            System.out.print("Enter sportName: ");
            String sportName = sc.nextLine();
            System.out.print("Enter teamsName : ");
            String teamsName = sc.nextLine();
            return new Sports(event_name, date, time, venue_name, total_seats, ticket_price, event_type, sportName);

        } else {
            System.out.println("Invalid event type.");
            return null;
        }
    }

    public void display_event_details(Event event) {
        event.display_event_details();
    }

    public void book_tickets(Event event, int num_tickets) {
        if (event.getAvailable_seats() >= num_tickets) {
            event.book_tickets(num_tickets);
            double cost = num_tickets * event.getTicket_price();
            System.out.println("Booking successful! Total cost: Rs. " + cost);
        } else {
            System.out.println("Not enough tickets available. Only " + event.getAvailable_seats() + " left.");
        }
    }

    public void cancel_tickets(Event event, int num_tickets) {
        event.cancel_booking(num_tickets);
        System.out.println("Cancellation successful.");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TicketBookingSystem system = new TicketBookingSystem();
        Event event = null;

        while (true) {
            System.out.println("\nMenu:\n1. Create Event\n2. Display Event Details\n3. Book Tickets\n4. Cancel Tickets\n5. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 1) {
                System.out.print("Enter event name: ");
                String ename = sc.nextLine();
                System.out.print("Enter date (YYYY-MM-DD): ");
                String date = sc.nextLine();
                System.out.print("Enter time (HH:MM): ");
                String time = sc.nextLine();
                System.out.print("Enter venue name: ");
                String vname = sc.nextLine();
                System.out.print("Enter total seats: ");
                int seats = sc.nextInt();
                System.out.print("Enter ticket price: ");
                double price = sc.nextDouble();
                sc.nextLine();
                System.out.print("Enter event type (Movie/Concert/Sports): ");
                String etype = sc.nextLine();

                event = system.create_event(ename, date, time, seats, price, etype, vname);

                if (event != null) {
                    System.out.println("Event created successfully.");
                }

            } else if (choice == 2) {
                if (event != null) {
                    system.display_event_details(event);
                } else {
                    System.out.println("No event created yet.");
                }

            } else if (choice == 3) {
                if (event != null) {
                    System.out.print("Enter number of tickets to book: ");
                    int t = sc.nextInt();
                    system.book_tickets(event, t);
                } else {
                    System.out.println("No event created yet.");
                }

            } else if (choice == 4) {
                if (event != null) {
                    System.out.print("Enter number of tickets to cancel: ");
                    int t = sc.nextInt();
                    system.cancel_tickets(event, t);
                } else {
                    System.out.println("No event created yet.");
                }

            } else if (choice == 5) {
                System.out.println("Exiting...");
                break;

            } else {
                System.out.println("Invalid choice.");
            }
        }

        sc.close();
    }
}
