/**
 * 
 */
/**
 * 
 */
module Task5_InheritanceAndPolymorphism {
}