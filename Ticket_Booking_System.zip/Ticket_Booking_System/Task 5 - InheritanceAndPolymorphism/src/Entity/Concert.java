package Entity;

public class Concert extends Event 
{
    private String artist;
    private String type;

    public Concert()
    {
    	
    	
    }

    public Concert(String event_name, String event_date, String event_time, String venue_name, int total_seats, double ticket_price, String artist, String type)
    {
        super(event_name, event_date, event_time, venue_name, total_seats, ticket_price, "Concert");
        this.artist = artist;
        this.type = type;
    }

    public String getArtist() { 
    	return artist;
    	}
    public void setArtist(String artist) { 
    	this.artist = artist;
    	}

    public String getType() {
    	return type; 
    	}
    public void setType(String type) { 
    	this.type = type;
    	}

    public void display_concert_details() {
        System.out.println("Artist: " + artist);
        System.out.println("Concert Type: " + type);
    }

    @Override
    public void display_event_details() {
        super.display_event_details();
        display_concert_details();
    }
}
