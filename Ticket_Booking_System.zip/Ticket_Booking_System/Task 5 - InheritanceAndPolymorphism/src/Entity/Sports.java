package Entity;

public class Sports extends Event {
    private String sportName;
    private String teamsName;

    public Sports() 
    {
    	
    }

    public Sports(String event_name, String event_date, String event_time, String venue_name, int total_seats, double ticket_price, String sportName, String teamsName) 
    {
        super(event_name, event_date, event_time, venue_name, total_seats, ticket_price, "Sports");
        this.sportName = sportName;
        this.teamsName = teamsName;
    }

    public String getSportName() { 
    	return sportName;
    	}
    public void setSportName(String sportName) { 
    	this.sportName = sportName;
    	}

    public String getTeamsName() { 
    	return teamsName;
    	}
    public void setTeamsName(String teamsName) { 
    	this.teamsName = teamsName; 
    	}

    public void display_sport_details() {
        System.out.println("Sport: " + sportName);
        System.out.println("Teams: " + teamsName);
    }

    @Override
    public void display_event_details() {
        super.display_event_details();
        display_sport_details();
    }
}

