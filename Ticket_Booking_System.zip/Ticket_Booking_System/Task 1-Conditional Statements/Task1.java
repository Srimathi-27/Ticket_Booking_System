import java.util.Scanner;

public class Task1
{
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.print("Enter available tickets: ");
        int availableTickets=scanner.nextInt();
        System.out.print("Enter number of tickets to book: ");
        int noOfBookingTicket=scanner.nextInt();
        if(availableTickets>=noOfBookingTicket) 
        {
            int remainingTickets=availableTickets-noOfBookingTicket;
            System.out.println("Booking successfully done!");
            System.out.println("Remaining tickets: " + remainingTickets);
        } 
        else 
        {
            System.out.println("Oh Oh..Sorry! Tickets unavailable. Only " + availableTickets + " tickets are available.");
        }

        scanner.close();
    }
}
