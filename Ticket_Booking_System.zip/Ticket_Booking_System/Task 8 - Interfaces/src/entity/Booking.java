package entity;

import java.util.ArrayList;
import java.util.List;

public class Booking {
    private static int bookingIdCounter = 1; 
    private int bookingId;
    private List<Customer> customers;
    private Event event;
    private int numTickets;
    private double totalCost;

    public Booking(Event event, List<Customer> customers, int numTickets, double totalCost) {
        this.bookingId = bookingIdCounter++;
        this.customers = customers;
        this.event = event;
        this.numTickets = numTickets;
        this.totalCost = totalCost;
    }

    public int getBookingId() {
        return bookingId;
    }

    public Event getEvent() {
        return event;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public int getNumTickets() {
        return numTickets;
    }

    public double getTotalCost() {
        return totalCost;
    }
}
