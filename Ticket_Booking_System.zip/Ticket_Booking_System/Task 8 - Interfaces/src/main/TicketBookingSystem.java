package main;

import entity.*;
import service.*;
import service.BookingSystemServiceProviderImpl;

import java.util.Scanner;

public class TicketBookingSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Venue venue = new Venue("Madison Square", "New York");

        IEventServiceProvider eventServiceProvider = new EventServiceProviderImpl();
        IBookingSystemServiceProvider bookingSystemServiceProvider = new BookingSystemServiceProviderImpl();

        Event event = null;

        while (true) {
            System.out.println("Enter command: create_event, book_tickets, cancel_tickets, get_event_details, get_available_seats, exit");
            String command = sc.nextLine();

            switch (command.toLowerCase()) {
                case "create_event":
                    System.out.println("Enter event name:");
                    String eventName = sc.nextLine();
                    System.out.println("Enter date (yyyy-mm-dd):");
                    String date = sc.nextLine();
                    System.out.println("Enter time (hh:mm:ss):");
                    String time = sc.nextLine();
                    System.out.println("Enter total seats:");
                    int totalSeats = sc.nextInt();
                    System.out.println("Enter ticket price:");
                    double ticketPrice = sc.nextDouble();
                    sc.nextLine(); // Consume the newline character
                    System.out.println("Enter event type (movie, concert, sport):");
                    String eventType = sc.nextLine();

                    event = eventServiceProvider.createEvent(eventName, date, time, totalSeats, ticketPrice, eventType, venue);
                    if (event != null) {
                        System.out.println("Event created successfully!");
                    }
                    break;

                case "book_tickets":
                    System.out.println("Enter event name:");
                    eventName = sc.nextLine();
                    System.out.println("Enter number of tickets:");
                    int numTickets = sc.nextInt();
                    sc.nextLine(); // Consume newline

                    Customer[] customers = new Customer[numTickets];
                    for (int i = 0; i < numTickets; i++) {
                        System.out.println("Enter customer name:");
                        String customerName = sc.nextLine();
                        customers[i] = new Customer(customerName);
                    }

                    bookingSystemServiceProvider.bookTickets(eventName, numTickets, customers);
                    break;

                case "get_event_details":
                    if (event != null) {
                        event.displayEventDetails();
                    } else {
                        System.out.println("No event found.");
                    }
                    break;

                case "get_available_seats":
                    if (event != null) {
                        System.out.println("Available seats: " + event.getAvailableSeats());
                    } else {
                        System.out.println("No event found.");
                    }
                    break;

                case "exit":
                    System.out.println("Exiting system.");
                    return;

                default:
                    System.out.println("Invalid command.");
            }
        }
    }
}
