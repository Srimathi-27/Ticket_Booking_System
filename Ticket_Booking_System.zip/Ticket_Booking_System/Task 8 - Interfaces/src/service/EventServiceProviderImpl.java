package service;

import entity.*;

public class EventServiceProviderImpl implements IEventServiceProvider {

    @Override
    public Event createEvent(String eventName, String date, String time, int totalSeats, double ticketPrice, String eventType, Venue venue) {
        Event event = null;
        switch (eventType.toLowerCase()) {
            case "movie":
                event = new Movie(eventName, date, time, venue, totalSeats, ticketPrice);
                break;
            case "concert":
                event = new Concert(eventName, date, time, venue, totalSeats, ticketPrice);
                break;
            case "sport":
                event = new Sport(eventName, date, time, venue, totalSeats, ticketPrice);
                break;
            default:
                System.out.println("Invalid event type.");
        }
        return event;
    }

    @Override
    public Event[] getEventDetails() {
        // Sample implementation
        return new Event[]{};
    }

    @Override
    public int getAvailableNoOfTickets() {
        return 100;  // Example
    }
}
