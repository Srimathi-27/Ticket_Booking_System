package service;

import entity.*;


import java.util.ArrayList;

public class BookingSystemServiceProviderImpl implements IBookingSystemServiceProvider {
    private ArrayList<Event> events = new ArrayList<>();

    @Override
    public void calculateBookingCost(int numTickets) {

        double totalCost = numTickets * 100; 
        System.out.println("Total cost for booking " + numTickets + " tickets is: " + totalCost);
    }

    public void bookTickets1(String eventName, int numTickets, Customer[] customers) {
        for (Event event : events) {
            if (event.getEventName().equalsIgnoreCase(eventName)) {
                event.bookTickets(numTickets);
                
            }
        }
    }

    @Override
    public void cancelBooking(int bookingId) {
        
    }

    @Override
    public void getBookingDetails(int bookingId) {
       
    }

	@Override
	public void bookTickets(String eventName, int numTickets, Customer[] customers) {
		
		
	}
}
