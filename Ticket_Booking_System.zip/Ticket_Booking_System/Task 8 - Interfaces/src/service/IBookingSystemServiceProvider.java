package service;

import entity.*;

public interface IBookingSystemServiceProvider {
    void calculateBookingCost(int numTickets);
    void bookTickets(String eventName, int numTickets, Customer[] customers);
    void cancelBooking(int bookingId);
    void getBookingDetails(int bookingId);
}
