import java.util.Scanner;

public class Task3
{
    public static void main(String[] args) 
    {
        Scanner scanner=new Scanner(System.in);
        while(true)
        {

        System.out.println("Available Ticket Types:\nSilver\n Gold\n Diamond");
        System.out.print("Enter ticket type: ");
        String Ttype=scanner.nextLine();

            if(Ttype.equalsIgnoreCase("exit"))
                break;

        System.out.print("Enter number of tickets: ");
        int noOfTickets=scanner.nextInt();
        scanner.nextLine();
        double TicketPrice;
        double totalCost;
        
        if(Ttype.equalsIgnoreCase("Silver"))
        {
            TicketPrice=200.0;
            totalCost=TicketPrice*noOfTickets;
            System.out.println("Total cost for Silver tickets:Rs. " + totalCost);
        } 
        else if(Ttype.equalsIgnoreCase("Gold")) 
        {
            TicketPrice=350.0;
            totalCost=TicketPrice*noOfTickets;
            System.out.println("Total cost for Gold tickets:Rs. " + totalCost);
        } 
        else if(Ttype.equalsIgnoreCase("Diamond")) 
        {
            TicketPrice=500.0;
            totalCost=TicketPrice*noOfTickets;
            System.out.println("Total cost for Diamond tickets:Rs. " + totalCost);
        } 
        else 
        {
            System.out.println("Invalid ticket type selected.");
        }
    }
        scanner.close();
    }
}
