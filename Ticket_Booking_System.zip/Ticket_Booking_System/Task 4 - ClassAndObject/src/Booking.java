public class Booking {
    private Event event;
    private int num_tickets;
    private double total_cost;

    public Booking(Event event) {
        this.event = event;
    }

    public double calculate_booking_cost(int num_tickets)
    {
        total_cost = num_tickets * event.getTicket_price();
        return total_cost;
    }

    public void book_tickets(int num_tickets) 
    {
        if(event.getAvailable_seats() >= num_tickets) 
        {
            this.num_tickets = num_tickets;
            event.book_tickets(num_tickets);
            System.out.println("Booking successful. Total cost: Rs." + calculate_booking_cost(num_tickets));
        } 
        else 
        {
            System.out.println("Not enough tickets available.");
        }
    }

    public void cancel_booking(int num_tickets)
    {
        event.cancel_booking(num_tickets);
        System.out.println("Cancelled " + num_tickets + " tickets.");
    }

    public int getAvailableNoOfTickets() 
    {
        return event.getAvailable_seats();
    }

    public void getEventDetails() 
    {
        event.display_event_details();
    }
}
