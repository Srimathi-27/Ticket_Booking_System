package dao;

import entity.Event;

public abstract class BookingSystem {
    public abstract void createEvent();
    public abstract void bookTickets();
    public abstract void cancelTickets();
    public abstract void getAvailableSeats();
}