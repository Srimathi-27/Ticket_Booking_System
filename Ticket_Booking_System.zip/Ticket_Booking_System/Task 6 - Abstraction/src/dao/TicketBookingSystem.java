package dao;

import entity.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TicketBookingSystem extends BookingSystem {
    private List<Event> events = new ArrayList<>();
    private Scanner sc = new Scanner(System.in);

    @Override
    public void createEvent() {
        System.out.println("Enter Event Type (Movie/Concert/Sport): ");
        String type = sc.nextLine();

        System.out.print("Enter Event Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Date: ");
        String date = sc.nextLine();
        System.out.print("Enter Time: ");
        String time = sc.nextLine();
        System.out.print("Enter Total Seats: ");
        int seats = Integer.parseInt(sc.nextLine());
        System.out.print("Enter Ticket Price: ");
        double price = Double.parseDouble(sc.nextLine());

        Event e = null;
        switch (type.toLowerCase()) {
            case "movie":
                System.out.print("Enter Genre: ");
                String genre = sc.nextLine();
                System.out.print("Enter Actor Name: ");
                String actor = sc.nextLine();
                System.out.print("Enter Actress Name: ");
                String actress = sc.nextLine();
                e = new Movie(name, date, time, seats, price, genre, actor, actress);
                break;
            case "concert":
                System.out.print("Enter Artist Name: ");
                String artist = sc.nextLine();
                System.out.print("Enter Type: ");
                String concertType = sc.nextLine();
                e = new Concert(name, date, time, seats, price, artist, concertType);
                break;
            case "sport":
                System.out.print("Enter Sport Name: ");
                String sport = sc.nextLine();
                System.out.print("Enter Teams (e.g., India vs Pakistan): ");
                String teams = sc.nextLine();
                e = new Sport(name, date, time, seats, price, sport, teams);
                break;
        }

        if (e != null) {
            events.add(e);
            System.out.println("Event created successfully!");
        } else {
            System.out.println("Invalid event type.");
        }
    }

    @Override
    public void bookTickets() {
        Event e = findEventByName();
        if (e != null) {
            System.out.print("Enter number of tickets: ");
            int num = Integer.parseInt(sc.nextLine());
            if (e.bookTickets(num)) {
                System.out.println("Tickets booked! Total cost: Rs." + (num * e.ticketPrice));
            } else {
                System.out.println("Not enough seats available.");
            }
        }
    }

    @Override
    public void cancelTickets() {
        Event e = findEventByName();
        if (e != null) {
            System.out.print("Enter number of tickets to cancel: ");
            int num = Integer.parseInt(sc.nextLine());
            if (e.cancelTickets(num)) {
                System.out.println("Tickets cancelled!");
            } else {
                System.out.println("Cannot cancel more than booked.");
            }
        }
    }

    @Override
    public void getAvailableSeats() {
        Event e = findEventByName();
        if (e != null) {
            System.out.println("Available Seats for " + e.getEventName() + ": " + e.getAvailableSeats());
        }
    }

    private Event findEventByName() {
        System.out.print("Enter Event Name: ");
        String name = sc.nextLine();
        for (Event e : events) {
            if (e.getEventName().equalsIgnoreCase(name)) return e;
        }
        System.out.println("Event not found.");
        return null;
    }
}

