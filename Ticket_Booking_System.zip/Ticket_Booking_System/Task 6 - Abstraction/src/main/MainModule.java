package main;

import dao.TicketBookingSystem;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TicketBookingSystem tbs = new TicketBookingSystem();
        boolean running = true;

        System.out.println("Welcome to the Ticket Booking System");

        while (running) {
            System.out.println("\n========================================");
            System.out.println("Please choose an option:");
            System.out.println("1️. Create Event");
            System.out.println("2️. Book Tickets");
            System.out.println("3️. Cancel Tickets");
            System.out.println("4️. Get Available Seats");
            System.out.println("5️. Exit");
            System.out.print("Enter your choice (1-5): ");

            String input = sc.nextLine();
            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 5.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.println("\nCreate New Event:");
                    tbs.createEvent();
                    break;
                case 2:
                    System.out.println("\nBook Tickets:");
                    tbs.bookTickets();
                    break;
                case 3:
                    System.out.println("\nCancel Tickets:");
                    tbs.cancelTickets();
                    break;
                case 4:
                    System.out.println("\nCheck Available Seats:");
                    tbs.getAvailableSeats();
                    break;
                case 5:
                    System.out.println("\nThank you for using the Ticket Booking System. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Please enter a valid option between 1 and 5.");
            }
        }

        sc.close();
    }
}
