package entity;

public class Sport extends Event {
    private String sportName;
    private String teamsName;

    public Sport(String eventName, String date, String time, int totalSeats, double ticketPrice, String sportName, String teamsName) {
        super(eventName, date, time, totalSeats, ticketPrice);
        this.sportName = sportName;
        this.teamsName = teamsName;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("🏆 Sport: " + sportName + " Match: " + teamsName);
    }
}
