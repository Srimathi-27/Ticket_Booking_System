package entity;

public class Movie extends Event {
    private String genre;
    private String actorName;
    private String actressName;

    public Movie(String eventName, String date, String time, int totalSeats, double ticketPrice, String genre, String actorName, String actressName) {
        super(eventName, date, time, totalSeats, ticketPrice);
        this.genre = genre;
        this.actorName = actorName;
        this.actressName = actressName;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("🎬 Movie: " + eventName + ", Genre: " + genre + ", Actor: " + actorName + ", Actress: " + actressName);
    }
}

