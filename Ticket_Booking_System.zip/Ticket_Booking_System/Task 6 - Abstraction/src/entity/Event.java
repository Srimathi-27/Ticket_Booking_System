package entity;

public abstract class Event {
    protected String eventName;
    protected String date;
    protected String time;
    protected int totalSeats;
    protected int bookedSeats;
    protected double ticketPrice;

    public Event(String eventName, String date, String time, int totalSeats, double ticketPrice) {
        this.eventName = eventName;
        this.date = date;
        this.time = time;
        this.totalSeats = totalSeats;
        this.bookedSeats = 0;
        this.ticketPrice = ticketPrice;
    }

    public abstract void displayEventDetails();

    public int getAvailableSeats() {
        return totalSeats - bookedSeats;
    }

    public boolean bookTickets(int numTickets) {
        if (bookedSeats + numTickets <= totalSeats) {
            bookedSeats += numTickets;
            return true;
        }
        return false;
    }

    public boolean cancelTickets(int numTickets) {
        if (bookedSeats >= numTickets) {
            bookedSeats -= numTickets;
            return true;
        }
        return false;
    }

    public String getEventName() {
        return eventName;
    }
}