package entity;

public class Concert extends Event {
    private String artist;
    private String type;

    public Concert(String eventName, String date, String time, int totalSeats, double ticketPrice, String artist, String type) {
        super(eventName, date, time, totalSeats, ticketPrice);
        this.artist = artist;
        this.type = type;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("🎵 Concert: " + eventName + ", Artist: " + artist + ", Type: " + type);
    }
}
