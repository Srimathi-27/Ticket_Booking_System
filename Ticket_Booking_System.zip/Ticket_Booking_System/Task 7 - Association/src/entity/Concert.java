package entity;

import java.time.LocalDate;
import java.time.LocalTime;

public class Concert extends Event {
    public Concert(String eventName, LocalDate eventDate, LocalTime eventTime, Venue venue, 
                   int totalSeats, double ticketPrice) {
        super(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Concert");
    }

    @Override
    public void printSpecialInfo() {
        System.out.println("Special Info: This is a concert event.");
    }
}