package entity;

import java.time.LocalDate;
import java.time.LocalTime;

public class Sport extends Event {
    public Sport(String eventName, LocalDate eventDate, LocalTime eventTime, Venue venue, 
                 int totalSeats, double ticketPrice) {
        super(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Sport");
    }

    @Override
    public void printSpecialInfo() {
        System.out.println("Special Info: This is a sports event.");
    }
}