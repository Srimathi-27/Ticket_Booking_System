package entity;

import java.time.LocalDate;
import java.time.LocalTime;

public class Movie extends Event {
    public Movie(String eventName, LocalDate eventDate, LocalTime eventTime, Venue venue, 
                 int totalSeats, double ticketPrice) {
        super(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Movie");
    }

    @Override
    public void printSpecialInfo() {
        System.out.println("Special Info: This is a movie event.");
    }
}
