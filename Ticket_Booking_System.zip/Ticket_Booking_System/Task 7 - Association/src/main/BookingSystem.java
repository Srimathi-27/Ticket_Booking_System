package main;
import entity.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class BookingSystem {
    private static List<Event> events = new ArrayList<>();

    public static Event createEvent(String eventName, String date, String time, int totalSeats, 
                                    double ticketPrice, String eventType, Venue venue) {
        LocalDate eventDate = LocalDate.parse(date);
        LocalTime eventTime = LocalTime.parse(time);
        
        Event event = null;
        switch (eventType.toLowerCase()) {
            case "movie":
                event = new Movie(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice);
                break;
            case "concert":
                event = new Concert(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice);
                break;
            case "sport":
                event = new Sport(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice);
                break;
            default:
                System.out.println("Invalid event type.");
        }

        if (event != null) {
            events.add(event);
            System.out.println("Event created successfully.");
        }
        return event;
    }

    public static double calculateBookingCost(Event event, int numTickets) {
        return event.getTicketPrice() * numTickets;
    }

    public static Booking bookTickets(String eventName, int numTickets, Customer[] customers) {
        Event event = null;
        for (Event e : events) {
            if (e.getEventName().equals(eventName)) {
                event = e;
                break;
            }
        }

        if (event != null) {
            if (numTickets <= event.getAvailableSeats()) {
                return new Booking(customers, event, numTickets);
            } else {
                System.out.println("Not enough available seats.");
            }
        } else {
            System.out.println("Event not found.");
        }
        return null;
    }
    public static void cancelBooking(int bookingId) {
        System.out.println("Booking canceled successfully.");
    }

    public static void getAvailableNoOfTickets() {
        for (Event event : events) {
            System.out.println("Event: " + event.getEventName() + " | Available Seats: " + event.getAvailableSeats());
        }
    }

    public static void getEventDetails(String eventName) {
        for (Event event : events) {
            if (event.getEventName().equals(eventName)) {
                event.displayEventDetails();
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Venue venue = new Venue("City Stadium", "123 Main Street");

        while (true) {
            System.out.println("\nTicket Booking System");
            System.out.println("1. Create Event");
            System.out.println("2. Book Tickets");
            System.out.println("3. Cancel Booking");
            System.out.println("4. Get Available Seats");
            System.out.println("5. Get Event Details");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Event Name: ");
                    scanner.nextLine(); // Consume newline
                    String eventName = scanner.nextLine();
                    System.out.print("Enter Event Date (YYYY-MM-DD): ");
                    String date = scanner.nextLine();
                    System.out.print("Enter Event Time (HH:MM): ");
                    String time = scanner.nextLine();
                    System.out.print("Enter Total Seats: ");
                    int totalSeats = scanner.nextInt();
                    System.out.print("Enter Ticket Price: ");
                    double ticketPrice = scanner.nextDouble();
                    System.out.print("Enter Event Type (Movie/Sport/Concert): ");
                    String eventType = scanner.next();
                    createEvent(eventName, date, time, totalSeats, ticketPrice, eventType, venue);
                    break;

                case 2:
                    System.out.print("Enter Event Name: ");
                    scanner.nextLine(); 
                    eventName = scanner.nextLine();
                    System.out.print("Enter Number of Tickets: ");
                    int numTickets = scanner.nextInt();
                    System.out.print("Enter Customer Details: ");
                    Customer[] customers = new Customer[numTickets];
                    for (int i = 0; i < numTickets; i++) {
                        System.out.print("Enter Customer Name: ");
                        scanner.nextLine(); 
                        String name = scanner.nextLine();
                        System.out.print("Enter Email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter Phone: ");
                        String phone = scanner.nextLine();
                        customers[i] = new Customer(name, email, phone);
                    }
                    bookTickets(eventName, numTickets, customers);
                    break;

                case 3:
                    System.out.print("Enter Booking ID to Cancel: ");
                    int bookingId = scanner.nextInt();
                    cancelBooking(bookingId);
                    break;

                case 4:
                    getAvailableNoOfTickets();
                    break;

                case 5:
                    System.out.print("Enter Event Name: ");
                    scanner.nextLine(); 
                    eventName = scanner.nextLine();
                    getEventDetails(eventName);
                    break;

                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}