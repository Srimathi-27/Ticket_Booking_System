package main;
import dao.*;
import entity.*;
import service.*;
import myexceptions.*;

import java.util.Scanner;

public class TicketBookingSystem
{
    public static void main(String[] args) throws EventNotFoundException, InvalidBookingIDException, NullPointerException {
        Scanner sc = new Scanner(System.in);

        IEventServiceProvider eventServiceProvider = new EventServiceProviderImpl();
        IBookingSystemServiceProvider bookingSystemServiceProvider = new BookingSystemServiceProviderImpl();

        Event event = null;

        while (true) {
            System.out.println("Enter the command from menu:\n create_event\n book_tickets\n get_event_details\n get_available_seats\n exit");
            String command = sc.nextLine();

            switch (command.toLowerCase()) {
                case "create_event":
                    try {
                        System.out.println("Enter event name:");
                        String eventName = sc.nextLine();
                        System.out.println("Enter date (yyyy-mm-dd):");
                        String date = sc.nextLine();
                        System.out.println("Enter time (hh:mm:ss):");
                        String time = sc.nextLine();
                        System.out.println("Enter total seats:");
                        int totalSeats = sc.nextInt();
                        System.out.println("Enter ticket price:");
                        double ticketPrice = sc.nextDouble();
                        System.out.println("Enter venue name: ");
                        String vname = sc.nextLine();
                        System.out.println("Enter venue address: ");
                        String vaddr = sc.nextLine();

                        Venue venue = new Venue(vname, vaddr);
                        sc.nextLine(); 
                        System.out.println("Enter event type (movie, concert, sport):");
                        String eventType = sc.nextLine();

                   
                        event = eventServiceProvider.createEvent(eventName, date, time, totalSeats, ticketPrice, eventType, venue);
                        if (event != null) {
                            System.out.println("Event created successfully!");
                        }
                    } catch (Exception e) {
                        System.out.println("Error while creating event: " + e.getMessage());
                    }
                    break;

                case "book_tickets":
                    try {
                        System.out.println("Enter event name:");
                        String eventName = sc.nextLine();
                        System.out.println("Enter number of tickets:");
                        int numTickets = sc.nextInt();
                        sc.nextLine(); 

                        Customer[] customers = new Customer[numTickets];
                        for (int i = 0; i < numTickets; i++) {
                            System.out.println("Enter customer name:");
                            String customerName = sc.nextLine();
                            customers[i] = new Customer(customerName);
                        }

          
                        bookingSystemServiceProvider.bookTickets(eventName, numTickets, customers);
                        System.out.println("Successfully Booked! ");
                    } catch (EventNotFoundException e) {
                        System.out.println(e.getMessage());
                    } catch (Exception e) {
                        System.out.println( e.getMessage());
                    }
                    break;

                case "get_event_details":
                    if (event != null) {
                        event.displayEventDetails();
                    } else {
                        System.out.println("No event found.");
                    }
                    break;

                case "get_available_seats":
                    if (event != null) {
                        System.out.println("Available seats: " + event.getAvailableSeats());
                    } else {
                        System.out.println("No event found.");
                    }
                    break;

                case "exit":
                    System.out.println("Exiting...");
                    sc.close(); 
                    return;

                default:
                    System.out.println("Invalid command.");
            }
        }
    }
}
