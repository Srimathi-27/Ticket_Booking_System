package service;

import java.util.List;

import entity.Customer;
import myexceptions.EventNotFoundException;
import myexceptions.InvalidBookingIDException;

public interface IBookingSystemServiceProvider {
    void calculateBookingCost(int numTickets);
    void bookTickets(String eventName, int numTickets, Customer[] customers) throws EventNotFoundException;
    void cancelBooking(int bookingId) throws InvalidBookingIDException;
    void getBookingDetails(int bookingId) throws InvalidBookingIDException;
	
}
