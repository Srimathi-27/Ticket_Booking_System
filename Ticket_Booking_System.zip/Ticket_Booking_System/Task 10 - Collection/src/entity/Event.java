package entity;
import java.time.LocalDate;
import java.time.LocalTime;

public abstract class Event {
    protected String eventName;
    protected LocalDate eventDate;
    protected LocalTime eventTime;
    protected Venue venue;
    protected int totalSeats;
    protected int availableSeats;
    protected double ticketPrice;

    public Event(String eventName, String date, String time, Venue venue, int totalSeats, double ticketPrice) {
        this.eventName = eventName;
        this.eventDate = LocalDate.parse(date);
        this.eventTime = LocalTime.parse(time);
        this.venue = venue;
        this.totalSeats = totalSeats;
        this.availableSeats = totalSeats;
        this.ticketPrice = ticketPrice;
    }
    public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public LocalDate getEventDate() {
		return eventDate;
	}

	public void setEventDate(LocalDate eventDate) {
		this.eventDate = eventDate;
	}

	public LocalTime getEventTime() {
		return eventTime;
	}

	public void setEventTime(LocalTime eventTime) {
		this.eventTime = eventTime;
	}

	public Venue getVenue() {
		return venue;
	}

	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	public int getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

    public abstract void displayEventDetails();

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void bookTickets(int tickets) {
        if (tickets <= availableSeats) {
            availableSeats -= tickets;
            System.out.println(tickets + " tickets booked successfully.");
        } else {
            System.out.println("Not enough seats available.");
        }
    }

	
    
}