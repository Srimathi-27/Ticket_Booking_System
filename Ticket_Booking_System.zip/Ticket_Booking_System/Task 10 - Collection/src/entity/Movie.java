package entity;

public class Movie extends Event {

    public Movie(String eventName, String date, String time, Venue venue, int totalSeats, double ticketPrice) {
        super(eventName, date, time, venue, totalSeats, ticketPrice);
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Movie Event: " + eventName);
        System.out.println("Date: " + eventDate + " Time: " + eventTime);
        System.out.println("Venue: " + venue);
        System.out.println("Total Seats: " + totalSeats + " Available Seats: " + availableSeats);
        System.out.println("Ticket Price: " + ticketPrice);
    }
}
