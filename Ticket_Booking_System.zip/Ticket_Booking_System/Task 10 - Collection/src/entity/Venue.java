package entity;

public class Venue {
    private String venueName;
    private String location;

    public Venue(String venueName, String location) {
        this.venueName = venueName;
        this.location = location;
    }

    public String getVenueName() {
        return venueName;
    }

    public void setVenueName(String venueName) {
        this.venueName = venueName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Venue [venueName=" + venueName + ", location=" + location + "]";
    }
}