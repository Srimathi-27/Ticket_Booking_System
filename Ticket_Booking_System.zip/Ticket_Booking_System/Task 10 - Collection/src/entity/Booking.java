package entity;

import java.util.Map;
import java.util.Set;

public class Booking
{
    private static int bookingIdCounter = 1;
    private int bookingId;
    private Event event;
    private Set<Customer> customers; 
    private Map<Integer, Customer> customerMap;
    private int numTickets;
    private double totalCost;

    public Booking(Event event, Set<Customer> customers, Map<Integer, Customer> customerMap, int numTickets, double totalCost) {
        this.bookingId = bookingIdCounter++;
        this.event = event;
        this.customers = customers;
        this.customerMap = customerMap;
        this.numTickets = numTickets;
        this.totalCost = totalCost;
    }

    public int getBookingId() {
        return bookingId;
    }

    public Event getEvent() {
        return event;
    }

    public Set<Customer> getCustomers() {
        return customers;
    }

    public Map<Integer, Customer> getCustomerMap() {
        return customerMap;
    }

    public int getNumTickets() {
        return numTickets;
    }

    public double getTotalCost() {
        return totalCost;
    }
}



