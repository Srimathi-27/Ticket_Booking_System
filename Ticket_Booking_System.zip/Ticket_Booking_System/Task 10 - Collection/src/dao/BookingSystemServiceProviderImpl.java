
package dao;
import service.*;

import entity.*;
import myexceptions.*;

import java.util.*;

public class BookingSystemServiceProviderImpl implements IBookingSystemServiceProvider {
    private List<Booking> bookings = new ArrayList<>();
    private Set<Event> events = new HashSet<>();
    private Map<String, Event> eventMap = new HashMap<>(); 
    private Map<Integer, Booking> bookingMap = new HashMap<>(); 

    @Override
    public void bookTickets(String eventName, int numTickets, Customer[] customerArray) throws EventNotFoundException {
        Event selectedEvent = eventMap.get(eventName.toLowerCase());
        if (selectedEvent == null) {
            throw new EventNotFoundException("Event not found: " + eventName);
        }

        if (selectedEvent.getAvailableSeats() < numTickets) {
            System.out.println("Not enough available seats for event: " + selectedEvent.getEventName());
            return;
        }

        Set<Customer> customerSet = new HashSet<>();
        Map<Integer, Customer> customerMap = new HashMap<>();

        for (int i = 0; i < customerArray.length; i++) {
            customerSet.add(customerArray[i]);
            customerMap.put(i + 1, customerArray[i]);
        }

        double totalCost = numTickets * selectedEvent.getTicketPrice();
        Booking booking = new Booking(selectedEvent, customerSet, customerMap, numTickets, totalCost);

        bookings.add(booking);
        bookingMap.put(booking.getBookingId(), booking);

        selectedEvent.setAvailableSeats(selectedEvent.getAvailableSeats() - numTickets);

        System.out.println("Booking successful! Booking ID: " + booking.getBookingId());
    }

    public void addEvent(Event event) {
        events.add(event);
        eventMap.put(event.getEventName().toLowerCase(), event);
    }

    public List<Event> getSortedEvents() {
        List<Event> sorted = new ArrayList<>(events);
        sorted.sort(Comparator.comparing(Event::getEventName, String.CASE_INSENSITIVE_ORDER)
            .thenComparing(e -> e.getVenue().getVenueName(), String.CASE_INSENSITIVE_ORDER));
        return sorted;
    }

    @Override
	public void calculateBookingCost(int numTickets) {
	    double totalCost = numTickets * 100; 
	    System.out.println("Total cost for booking " + numTickets + " tickets is: " + totalCost);
	}

	

	@Override
	public void cancelBooking(int bookingId) throws InvalidBookingIDException {
	    Booking target = null;
	    for (Booking booking : bookings) {
	        if (booking.getBookingId() == bookingId) {
	            target = booking;
	            break;
	        }
	    }

	    if (target == null) {
	        throw new InvalidBookingIDException("Booking ID " + bookingId + " not found.");
	    }

	    target.getEvent().setAvailableSeats(
	        target.getEvent().getAvailableSeats() + target.getNumTickets()
	    );
	    bookings.remove(target);
	    System.out.println("Booking cancelled successfully.");
	}

	@Override
	public void getBookingDetails(int bookingId) throws InvalidBookingIDException {
	    for (Booking booking : bookings) {
	        if (booking.getBookingId() == bookingId) {
	            System.out.println("Booking ID: " + booking.getBookingId());
	            System.out.println("Event: " + booking.getEvent().getEventName());
	            System.out.println("No. of Tickets: " + booking.getNumTickets());
	            System.out.println("Total Cost: " + booking.getTotalCost());
	            for (Customer c : booking.getCustomers()) {
	                System.out.println("Customer Name: " + c.getCustomerName());
	            }
	            return;
	        }
	    }

	    throw new InvalidBookingIDException("No booking found with ID: " + bookingId);
	}
}