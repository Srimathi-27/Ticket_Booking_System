package dao;

import entity.*;
import myexceptions.EventNotFoundException;
import myexceptions.InvalidBookingIDException;
import service.IBookingSystemServiceProvider;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BookingSystemServiceProviderImpl implements IBookingSystemServiceProvider {

	private List<Event> events = new ArrayList<>();
	private List<Booking> bookings = new ArrayList<>();

	public void addEvent(Event event) {
	    events.add(event);
	}

	public List<Event> getAllEvents() {
	    return events;
	}

	@Override
	public void calculateBookingCost(int numTickets) {
	    double totalCost = numTickets * 100; 
	    System.out.println("Total cost for booking " + numTickets + " tickets is: " + totalCost);
	}

	@Override
	public void bookTickets(String eventName, int numTickets, Customer[] customers) throws EventNotFoundException {
	    Event selectedEvent = null;

	    for (Event event : events) {
	        if (event.getEventName().equalsIgnoreCase(eventName)) {
	            selectedEvent = event;
	            break;
	        }
	    }

	    if (selectedEvent == null) {
	        throw new EventNotFoundException("Event not found: " + eventName);
	    }

	    if (selectedEvent.getAvailableSeats() < numTickets) {
	        System.out.println("Not enough available seats for event: " + selectedEvent.getEventName());
	        return;
	    }

	    List<Customer> customerList = new ArrayList<>(Arrays.asList(customers));

	
	    Booking booking = new Booking(selectedEvent, customerList, numTickets, numTickets * selectedEvent.getTicketPrice());

	
	    bookings.add(booking);

	   
	    selectedEvent.setAvailableSeats(selectedEvent.getAvailableSeats() - numTickets);

	  
	    System.out.println("Booking successful! Booking ID: " + booking.getBookingId());
	}


	@Override
	public void cancelBooking(int bookingId) throws InvalidBookingIDException {
	    Booking target = null;
	    for (Booking booking : bookings) {
	        if (booking.getBookingId() == bookingId) {
	            target = booking;
	            break;
	        }
	    }

	    if (target == null) {
	        throw new InvalidBookingIDException("Booking ID " + bookingId + " not found.");
	    }

	    target.getEvent().setAvailableSeats(
	        target.getEvent().getAvailableSeats() + target.getNumTickets()
	    );
	    bookings.remove(target);
	    System.out.println("Booking cancelled successfully.");
	}

	@Override
	public void getBookingDetails(int bookingId) throws InvalidBookingIDException {
	    for (Booking booking : bookings) {
	        if (booking.getBookingId() == bookingId) {
	            System.out.println("Booking ID: " + booking.getBookingId());
	            System.out.println("Event: " + booking.getEvent().getEventName());
	            System.out.println("No. of Tickets: " + booking.getNumTickets());
	            System.out.println("Total Cost: " + booking.getTotalCost());
	            for (Customer c : booking.getCustomers()) {
	                System.out.println("Customer Name: " + c.getCustomerName());
	            }
	            return;
	        }
	    }

	    throw new InvalidBookingIDException("No booking found with ID: " + bookingId);
	}
}